// import java.lang.*;
import java.util.Scanner;

//CurrencyConverter
public class CurrencyConverter
{

    public static void main(String[] args) {
        System.out.println("1 Ruppe");
        System.out.println("2 Dollar");
        System.out.println("3 Euro");
        System.out.println("4 Dirham");
        System.out.println("5 Bhat");
        System.out.println("6 Pound");
        System.out.println("7 Ruble");
        System.out.println("8 won");
        System.out.println("9 Riyal");
        System.out.println("10 Yen");
        System.out.println("11 Taka");
        System.out.println("12 Yuan");
        System.out.println("13 Rupiah");
        System.out.println("14 Lira");
        System.out.println("15 Afghani");

        // take input
        Scanner sc = new Scanner(System.in);
        System.out.println("Choose the currency");
        int choice = sc.nextInt();
        System.out.println("Enter the amount");
        double amount = sc.nextDouble();

        // convert the amount
        switch (choice) {
            case 1:
                Ruppe_to_other(amount);
                break;
            case 2:
                Dollar_to_other(amount);
                break;
            case 3:
                Euro_to_other(amount);
                break;
            case 4:
                Dirham_to_other(amount);
                break;
            case 5:
                Bhat_to_other(amount);
                break;
            case 6:
                Pound_to_other(amount);
                break;
            case 7:
                Ruble_to_other(amount);
                break;
            case 8:
                Won_to_other(amount);
                break;
            case 9:
                Riyal_to_other(amount);
                break;
            case 10:
                Yen_to_other(amount);
                break;
            case 11:
                Taka_to_other(amount);
                break;
            case 12:
                Yuan_to_other(amount);
                break;
            case 13:
                Rupiah_to_other(amount);
                break;
            case 14:
                Lira_to_other(amount);
                break;
            case 15:
                Afghani_to_other(amount);
                break;
            default:
                System.out.println("Invalid choice");
        }

    }

public static void Ruppe_to_other(double amt) 
{
    System.out.println(amt+" Ruppe = " + (amt*0.012) + " Dollar");
    System.out.println();
    
    System.out.println(amt+" Ruppe = " + (amt*0.011) + " Euro");
    System.out.println();
	
    System.out.println(amt+" Ruppe = " + (amt*0.044) + " Dirham");
	System.out.println();
	
    System.out.println(amt+" Ruppe = " + (amt*3.94) + " Bhat");
	System.out.println();
	
    System.out.println(amt+" Ruppe = " + (amt*0.0097) + " Pound");
	System.out.println();
	
    System.out.println(amt+" Ruppe = " + (amt*0.99) + " Ruble");
	System.out.println();
	
    System.out.println(amt+" Ruppe = " + (amt*0.063) + " Won");
	System.out.println();
	
    System.out.println(amt+" Ruppe = " + (amt*0.045) + " Riyal");
    System.out.println();
	
    System.out.println(amt+" Ruppe = " + (amt*1.69) + " Yen");
    System.out.println();
	
    System.out.println(amt+" Ruppe = " + (amt*1.31) + " Taka");
    System.out.println();
	
    System.out.println(amt+" Ruppe = " + (amt*0.086) + " Yuan");
    System.out.println();
	
    System.out.println(amt+" Ruppe = " + (amt*0.0055) + " Rupiah");
    System.out.println();
	
    System.out.println(amt+" Ruppe = " + (amt*0.283) + " Lira");
    System.out.println();
	
    System.out.println(amt+" Ruppe = " + (amt*1.043) + " Afghani");
    System.out.println();
}

public static void Dollar_to_other(double amt) 
{
    System.out.println(amt+" Dollar = " + (amt*82.78) + " Ruppe");
    System.out.println();
    
    System.out.println(amt+" Dollar = " + (amt*0.93) + " Euro");
	System.out.println();
	
    System.out.println(amt+" Dollar = " + (amt*3.67) + " Dirham");
	System.out.println();
	
    System.out.println(amt+" Dollar = " + (amt*34.845) + " Bhat");
	System.out.println();
	
    System.out.println(amt+" Dollar = " + (amt*0.803) + " Pound");
	System.out.println();
	
    System.out.println(amt+" Dollar = " + (amt*82.130) + " Ruble");
	System.out.println();
	
    System.out.println(amt+" Dollar = " + (amt*900) + " Won");
	System.out.println();
	
    System.out.println(amt+" Dollar = " + (amt*3.74) + " Riyal");
	System.out.println();
	
    System.out.println(amt+" Dollar = " + (amt*139) + " Yen");
	System.out.println();
	
    System.out.println(amt+" Dollar = " + (amt*106) + " Taka");
	System.out.println();
	
    System.out.println(amt+" Dollar = " + (amt*7.139) + " Yuan");
	System.out.println();
	
    System.out.println(amt+" Dollar = " + (amt*14897) + " Rupiah");
	System.out.println();
	
    System.out.println(amt+" Dollar = " + (amt*23.32) + " Lira");
	System.out.println();
	
    System.out.println(amt+" Dollar = " + (amt*86) + " Afghani");
}

public static void Euro_to_other(double amt)
{
    System.out.println(amt+" Euro = " + (amt*80.85) + " Ruppe");
    System.out.println();

    System.out.println(amt+" Euro = " + (amt*1.08) + " Dollar");
	System.out.println();
	
    System.out.println(amt+" Euro = " + (amt*3.94) + " Dirham");
	System.out.println();
	
    System.out.println(amt+" Euro = " + (amt*37.45) + " Bhat");
    System.out.println();
	
    System.out.println(amt+" Euro = " + (amt*649) + " Pound");
    System.out.println();
	
    System.out.println(amt+" Euro = " + (amt*91.30) + "Ruble");
    System.out.println();

    System.out.println(amt+" Euro = " + (amt*1379) + " Won");
    System.out.println();

    System.out.println(amt+" Euro = " + (amt*4.05) + " Riyal");
    System.out.println();

    System.out.println(amt+" Euro = " + (amt*151) + " Yen");
    System.out.println();
	
    System.out.println(amt+" Euro = " + (amt*117) + " Taka");
    System.out.println();
	
    System.out.println(amt+" Euro = " + (amt*7.73) + " Yuan");
    System.out.println();

    System.out.println(amt+" Euro = " + (amt*16104) + " Rupiah");
    System.out.println();

    System.out.println(amt+" Euro = " + (amt*25.58) + " Lira");
    System.out.println();

    System.out.println(amt+" Euro = " + (amt*93.09) + " Afghani");
}

public static void Dirham_to_other(double amt)
{
    System.out.println(amt+" Dirham = " + (amt*22.50) + " Ruppe");
    System.out.println();

    System.out.println(amt+" Dirham = " + (amt*0.27) + " Dollar");
	System.out.println();

    System.out.println(amt+" Dirham = " + (amt*0.25) + " Euro");
	System.out.println();
	
    System.out.println(amt+" Dirham = " + (amt*9.44) + " Bhat");
    System.out.println();

    System.out.println(amt+" Dirham = " + (amt*0.22) + " Pound");
    System.out.println();

    System.out.println(amt+" Dirham = " + (amt*23) + " Ruble");
    System.out.println();

    System.out.println(amt+" Dirham = " + (amt*347) + " Won");
    System.out.println();

    System.out.println(amt+" Dirham = " + (amt*1.02) + " Riyal");
    System.out.println();

    System.out.println(amt+" Dirham = " + (amt*38.09) + " Yen");
    System.out.println();

    System.out.println(amt+" Dirham = " + (amt*29.52) + " Taka");
    System.out.println();

    System.out.println(amt+" Dirham = " + (amt*1.95) + " Yuan");
    System.out.println();
	
    System.out.println(amt+" Dirham = " + (amt*4057) + " Rupiah");
    System.out.println();

    System.out.println(amt+" Dirham = " + (amt*6.45) + " Lira");
    System.out.println();

    System.out.println(amt+" Dirham = " + (amt*23.45) + " Afghani");
}

public static void Bhat_to_other(double amt)
{
   
    System.out.println(amt+" Bhat = " + (amt*2.34  ) + " Ruppe");  
     System.out.println();

    System.out.println(amt+" Bhat = " + (amt*0.028 ) + " Dollar");
     System.out.println();

    System.out.println(amt+" Bhat = " + (amt*0.024 ) + " Euro");
     System.out.println();

    System.out.println(amt+" Bhat = " + (amt*0.10  ) + " Dirham");
     System.out.println();

    System.out.println(amt+" Bhat = " + (amt*0.02  ) + " Pound");
     System.out.println();

    System.out.println(amt+" Bhat = " + (amt*1.23  ) + " Ruble");
     System.out.println();

    System.out.println(amt+"Bhat = " +  (amt*35.32  ) + " Won");
     System.out.println();

    System.out.println(amt+" Bhat = " + (amt*0.10  ) + " Riyal");
     System.out.println();

    System.out.println(amt+" Bhat = " + (amt*3.03  ) + " Yen");
     System.out.println();

    System.out.println(amt+" Bhat = " + (amt*2.29  ) + " Taka");
     System.out.println();

    System.out.println(amt+" Bhat = " + (amt*0.18  ) + " Yuan");
     System.out.println();

    System.out.println(amt+" Bhat = " + (amt*393.57) + " Rupiah");
     System.out.println();

    System.out.println(amt+" Bhat = " + (amt*0.22  ) + " Lira");
     System.out.println();

    System.out.println(amt+" Bhat = " + (amt*1.91  ) + " Afghani");

}

public static void Pound_to_other(double amt)
{
    System.out.println(amt+" Bhat = " +  (amt*99.09    ) + " Ruppe"); 
     System.out.println();

    System.out.println(amt+" Bhat = " +  (amt*1.37     ) + " Dollar");
     System.out.println();

    System.out.println(amt+" Bhat = " +  (amt*1.16     ) + " Euro");
     System.out.println();

	System.out.println(amt+" Bhat = " +  (amt*5.04     ) + " Dirham");
     System.out.println();

    System.out.println(amt+" Dirham = " +(amt*42.66    ) + " Bhat");
     System.out.println();

    System.out.println(amt+" Dirham = " +(amt*82.60    ) + " Ruble");
     System.out.println();

    System.out.println(amt+" Dirham = " +(amt*1.182 ) + " Won");
     System.out.println();

    System.out.println(amt+" Dirham = " +(amt*5.12     ) + " Riyal");
     System.out.println();

    System.out.println(amt+" Dirham = " +(amt*151.15   ) + " Yen");
     System.out.println();

    System.out.println(amt+" Dirham = " +(amt*116.15   ) + " Taka");
     System.out.println();

    System.out.println(amt+" Dirham = " +(amt*8.98     ) + " Yuan");
     System.out.println();

    System.out.println(amt+" Dirham = " +(amt*19.599) + " Rupiah");
     System.out.println();

    System.out.println(amt+" Dirham = " +(amt*15.10    ) + " Lira");
     System.out.println();

    System.out.println(amt+" Dirham = " +(amt*129.97   ) + " Afghani");
}

public static void Ruble_to_other(double amt)
{
    System.out.println(amt+" Ruble = " +  (amt*0.94  ) + " Ruppe");   
     System.out.println();

     System.out.println(amt+"  Ruble = " +(amt*0.014 ) + " Dollar");
      System.out.println();

     System.out.println(amt+" Ruble = " + (amt*0.012 ) + " Euro");
      System.out.println();

     System.out.println(amt+" Ruble = " + (amt*0.051 ) + " Dirham");
      System.out.println();

     System.out.println(amt+" Ruble = " + (amt*0.43  ) + "Bhat ");
      System.out.println();

     System.out.println(amt+" Ruble = " + (amt*0.01  ) + " pound");
      System.out.println();

     System.out.println(amt+" Ruble = " + (amt*16.2  ) + " won ");
      System.out.println();

     System.out.println(amt+" Ruble = " + (amt*0.051 ) + " riyal");
      System.out.println();

     System.out.println(amt+" Ruble = " + (amt*1.56  )  + " yen");
      System.out.println();

     System.out.println(amt+" Ruble = " + (amt*1.19  ) + " taka");
      System.out.println();

     System.out.println(amt+" Ruble = " + (amt*0.092 ) + "yuan ");
      System.out.println();

     System.out.println(amt+" Ruble = " + (amt*201.79) + "rupiah ");
      System.out.println();

     System.out.println(amt+" Ruble = " + (amt*0.12  )  + "lira ");
      System.out.println();

     System.out.println(amt+" Ruble = " + (amt*1.09  ) + "Afghani ");


}

public static void Won_to_other(double amt)
{
    System.out.println(amt+"  Won = " + (amt* 0.065  ) + " Ruppe");  
     System.out.println();

    System.out.println(amt+"  Won = " + (amt* 0.00089) + " Dollar");
     System.out.println();

	System.out.println(amt+"  Won = " + (amt* 0.00076) + " Euro");
     System.out.println();

	System.out.println(amt+"  Won = " + (amt* 0.00328) + " Dirham");
     System.out.println();

    System.out.println(amt+"  Won = " + (amt* 0.028  ) + " Bhat");
     System.out.println();

    System.out.println(amt+"  Won = " + (amt* 0.00064) + " Pound");
     System.out.println();

    System.out.println(amt+"  Won = " + (amt* 0.049  ) + " Ruble");
     System.out.println();

    System.out.println(amt+"  Won = " + (amt* 0.0033 ) + " Riyal");
     System.out.println();

    System.out.println(amt+"  Won = " + (amt* 0.096  ) + " Yen");
     System.out.println();

    System.out.println(amt+"  Won = " + (amt* 0.073  ) + " Taka");
     System.out.println();

    System.out.println(amt+"  Won = " + (amt* 0.0056 ) + " yuan");
     System.out.println();

    System.out.println(amt+"  Won = " + (amt* 12.19  ) + " Rupiah");
     System.out.println();

    System.out.println(amt+"  Won = " + (amt* 0.0075 ) + " Lira");
     System.out.println();

    System.out.println(amt+"  Won = " + (amt* 0.065  ) + " Afghani");
     System.out.println();
  
}

public static void Riyal_to_other(double amt)
{
    System.out.println(amt+"  Riyal = " + (amt* 19.29   ) + " Ruppe");    
     System.out.println();

    System.out.println(amt+"  Riyal = " + (amt* 0.26    ) + " Dollar");
     System.out.println();

	System.out.println(amt+"  Riyal = " + (amt* 0.22    ) + " Euro");
     System.out.println();

	System.out.println(amt+"  Riyal = " + (amt* 0.95    ) + " Dirham");
     System.out.println();

    System.out.println(amt+"  Riyal = " + (amt* 8.01    ) + " Bhat");
     System.out.println();

    System.out.println(amt+"  Riyal = " + (amt* 0.19    ) + "Pound");
     System.out.println();

    System.out.println(amt+"  Riyal = " + (amt* 3.67    ) + " Ruble");
     System.out.println();

    System.out.println(amt+"  Riyal = " + (amt* 526.32  ) + " Won");
     System.out.println();

    System.out.println(amt+"  Riyal = " + (amt* 30.83   ) + " Yen");
     System.out.println();

    System.out.println(amt+"  Riyal = " + (amt* 23.52   ) + " Taka");
     System.out.println();

    System.out.println(amt+" Riyal = " +  (amt* 1.81    ) + " yuan");
     System.out.println();

    System.out.println(amt+" Riyal = " +  (amt* 3.949) + " Rupiah");
     System.out.println();

    System.out.println(amt+" Bhat = " +   (amt* 3.04    ) + " Lira");
     System.out.println();

    System.out.println(amt+" Riyal= " +   (amt* 26.35   ) + " Afghani");
	
}

public static void Yen_to_other(double amt)
{
    System.out.println(amt+" Yen = " + (amt*0.65  ) + " Ruppe");   
     System.out.println();

    System.out.println(amt+" Yen = " + (amt*0.009 ) + " Dollar");
     System.out.println();

	System.out.println(amt+" Yen = " + (amt*0.008 ) + " Euro");
     System.out.println();

	System.out.println(amt+" Yen = " + (amt*0.036 ) + " Dirham");
     System.out.println();

    System.out.println(amt+" Yen = " + (amt*0.31  ) + " Bhat");
     System.out.println();

    System.out.println(amt+" Yen = " + (amt*0.007 ) + " Pound");
     System.out.println();

    System.out.println(amt+" Yen = " + (amt*0.15  ) + " Ruble");
     System.out.println();

    System.out.println(amt+" Yen = " + (amt*10.89 ) + " Won");
     System.out.println();

    System.out.println(amt+" Yen = " + (amt*0.032 ) + " Riyal");
     System.out.println();

    System.out.println(amt+" Yen = " + (amt*0.76  ) + " Taka");
     System.out.println();

    System.out.println(amt+" Yen = " + (amt*0.059 ) + " yuan");
     System.out.println();

    System.out.println(amt+" Yen = " + (amt*129.11) + " Rupiah");
     System.out.println();

    System.out.println(amt+" Yen = " + (amt*0.079 ) + " Lira");
     System.out.println();

    System.out.println(amt+" Yen = " + (amt*0.68  ) + " Afghani");  
}

public static void Taka_to_other(double amt)
{
    
    System.out.println(amt+" Taka = " + (amt*0.84    ) + " Ruppe");    
     System.out.println();

    System.out.println(amt+" Taka = " + (amt*0.011   ) + " Dollar");
     System.out.println();

	System.out.println(amt+" Taka = " + (amt* 0.009  ) + " Euro");
     System.out.println();

	System.out.println(amt+" Taka = " + (amt*0.041   ) + " Dirham");
     System.out.println();

    System.out.println(amt+" Taka = " + (amt*0.35   ) + " Bhat");
     System.out.println();

    System.out.println(amt+" Taka = " + (amt*0.008   ) + " Pound");
     System.out.println();

    System.out.println(amt+" Taka = " + (amt*0.67   ) + " Ruble");
     System.out.println();

    System.out.println(amt+" Taka = " + (amt* 9.66  ) + " Won");
     System.out.println();

    System.out.println(amt+" Taka = " + (amt* 0.043  ) + " Riyal");
     System.out.println();

    System.out.println(amt+" Taka = " + (amt* 1.32  ) + " Yen");
     System.out.println();

    System.out.println(amt+" Taka = " + (amt* 0.081  ) + " yuan");
     System.out.println();

    System.out.println(amt+" Taka = " + (amt*177.49   ) + " Rupiah");
     System.out.println();

    System.out.println(amt+" Taka = " + (amt*0.11   ) + " Lira");
     System.out.println();

    System.out.println(amt+" Taka = " + (amt*0.94   ) + " Afghani");  
}

public static void Yuan_to_other(double amt)
{
    System.out.println(amt+" Yuan = " + (amt* 10.84  ) + " Ruppe");    
     System.out.println();

    System.out.println(amt+" Yuan = " + (amt*0.15    ) + " Dollar");
     System.out.println();

	System.out.println(amt+" Yuan = " + (amt*0.13    ) + " Euro");
     System.out.println();

	System.out.println(amt+" Yuan = " + (amt*0.55    ) + " Dirham");
     System.out.println();

    System.out.println(amt+" Yuan = " + (amt*4.65    ) + " Bhat");
     System.out.println();

    System.out.println(amt+" Yuan = " + (amt*0.11    ) + " Pound");
     System.out.println();

    System.out.println(amt+" Yuan = " + (amt*8.52    ) + " Ruble");
     System.out.println();

    System.out.println(amt+" Yuan = " + (amt*122.50  ) + " Won");
     System.out.println();

    System.out.println(amt+" Yuan = " + (amt*0.55    ) + " Riyal");
     System.out.println();

    System.out.println(amt+" Yuan = " + (amt*16.15   ) + " Yen");
     System.out.println();

    System.out.println(amt+" Yuan = " + (amt*12.25   ) + " Taka");
     System.out.println();

    System.out.println(amt+" Yuan = " + (amt*26689) + " Rupiah");
     System.out.println();

    System.out.println(amt+" Yuan = " + (amt*20.6    ) + " Lira");
     System.out.println();

    System.out.println(amt+" Yuan = " + (amt*178.11  ) + " Afghani");  
}

public static void Rupiah_to_other(double amt)
{
    System.out.println(amt+" Rupiah = " + (amt*0.0050  ) + " Ruppe");    
     System.out.println();

    System.out.println(amt+" Rupiah = " + (amt*0.000068) + " Dollar");
     System.out.println();

	System.out.println(amt+" Rupiah = " + (amt*0.000057) + " Euro");
     System.out.println();

	System.out.println(amt+" Rupiah = " + (amt*0.00024 ) + " Dirham");
     System.out.println();

    System.out.println(amt+" Rupiah = " + (amt*0.0020  ) + " Bhat");
     System.out.println();

    System.out.println(amt+" Rupiah = " + (amt*0.000046) + " Pound");
     System.out.println();

    System.out.println(amt+" Rupiah = " + (amt*0.0042  ) + " Ruble");
     System.out.println();

    System.out.println(amt+" Rupiah = " + (amt*0.058   ) + " Won");
     System.out.println();

    System.out.println(amt+" Rupiah = " + (amt*0.00025 ) + " Riyal");
     System.out.println();

    System.out.println(amt+" Rupiah = " + (amt*0.0074  ) + " Yen");
     System.out.println();

    System.out.println(amt+" Rupiah = " + (amt*0.0060  ) + " Taka");
     System.out.println();

    System.out.println(amt+" Rupiah = " + (amt*0.000038) + " yuan");
     System.out.println();

    System.out.println(amt+" Rupiah = " + (amt*0.000074) + " Lira");
     System.out.println();

    System.out.println(amt+" Rupiah = " + (amt*0.00064 ) + " Afghani");  
}

public static void Lira_to_other(double amt)
{
    System.out.println(amt+" Lira = " + (amt*84.89    ) + " Ruppe");    
     System.out.println();

    System.out.println(amt+" Lira = " + (amt*1.16     ) + " Dollar");
     System.out.println();

	System.out.println(amt+" Lira = " + (amt*0.99     ) + " Euro");
     System.out.println();

	System.out.println(amt+" Lira = " + (amt*4.29     ) + " Dirham");
     System.out.println();

    System.out.println(amt+" Lira = " + (amt*36.22    ) + " Bhat");
     System.out.println();

    System.out.println(amt+" Lira = " + (amt*0.83     ) + " Pound");
     System.out.println();

    System.out.println(amt+" Lira = " + (amt*101.39   ) + " Ruble");
     System.out.println();

    System.out.println(amt+" Lira = " + (amt*1456) + " Won");
     System.out.println();

    System.out.println(amt+" Lira = " + (amt*4.32     ) + " Riyal");
     System.out.println();

    System.out.println(amt+" Lira = " + (amt*127.04   ) + " Yen");
     System.out.println();

    System.out.println(amt+" Lira = " + (amt*96.84    ) + " Taka");
     System.out.println();

    System.out.println(amt+" Lira = " + (amt*7.49     ) + " yuan");
     System.out.println();

    System.out.println(amt+" Lira = " + (amt*16303) + " Rupiah");
     System.out.println();

    System.out.println(amt+" Lira = " + (amt*141.09   ) + " Afghani");   
}

public static void Afghani_to_other(double amt)
{
    System.out.println(amt+"  Afghani = " + (amt*0.97  ) + " Ruppe");   
     System.out.println();

    System.out.println(amt+"  Afghani = " + (amt*0.013 ) + " Dollar");
     System.out.println();

	System.out.println(amt+"  Afghani = " + (amt*0.011 ) + " Euro");
     System.out.println();

	System.out.println(amt+"  Afghani = " + (amt*0.049 ) + " Dirham");
     System.out.println();

    System.out.println(amt+"  Afghani = " + (amt*0.41  ) + " Bhat");
     System.out.println();

    System.out.println(amt+"  Afghani = " + (amt*0.0093) + " Pound");
     System.out.println();

    System.out.println(amt+"  Afghani = " + (amt*0.71  ) + " Ruble");
     System.out.println();

    System.out.println(amt+"  Afghani = " + (amt*10.20 ) + " Won");
     System.out.println();

    System.out.println(amt+"  Afghani = " + (amt*0.049 ) + " Riyal");
     System.out.println();

    System.out.println(amt+"  Afghani = " + (amt*1.45  ) + " Yen");
     System.out.println();

    System.out.println(amt+"  Afghani = " + (amt*1.11  ) + " Taka");
     System.out.println();

    System.out.println(amt+"  Afghani = " + (amt*0.086 ) + " yuan");
     System.out.println();

    System.out.println(amt+"  Afghani = " + (amt*187.44) + " Rupiah");
     System.out.println();

    System.out.println(amt+"  Afghani = " + (amt*0.071 ) + " Lira");
}

}